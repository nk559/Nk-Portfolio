import React from 'react';

class Class extends React.Component{
    render(){
        return(
            <div>It is my first class component</div>
        )
    }
}
export default Class;