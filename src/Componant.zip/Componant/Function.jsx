import React from 'react'

export default function Function() {
  return (
    <div>it is my first functional component</div>
  )
}
